
package johnbr.textchecker;

import java.util.Scanner;

public class TextChecker {

    public static void main(String[] args) {
        System.out.println("Bigger number text checker");
    
        float numberOne = 0;
        float numberTwo = 0;
        
        System.out.println("You will be asked for two numbers.\n The program will then tell you which number was bigger.");
        
        System.out.println("Please enter the first number: ");
        Scanner scanner1 = new Scanner(System.in);
        
        if(!scanner1.hasNext("[A-Za-z]*")) {
            
            numberOne = scanner1.nextFloat();
            System.out.println("You entered " + numberOne);
            
            System.out.println("Please enter the second number: ");
            Scanner scanner2 = new Scanner(System.in);
            
            if(!scanner2.hasNext("[A-Za-z]*")) {

                numberTwo = scanner2.nextFloat();
                System.out.println("You entered " + numberTwo);

                if (numberOne > numberTwo) {
                    System.out.println("The bigger number was: " + numberOne);
                }
                else if (numberTwo > numberOne) {
                    System.out.println("The bigger number was: " + numberTwo);
                }
                else if (numberOne == numberTwo) {
                    System.out.println("The two numbers were the same!");
                }
                else {
                    System.out.println("There was a problem!");
                }
            }
            else {
            System.out.println("Sorry, you didn't enter a number.");
            }
                    
        } else {
            System.out.println("Sorry, you didn't enter a number.");
        }
        
         
        
        System.out.println("Divide number text checker");
        float number1 = 0;
        float number2 = 0;
        float result;
                
        System.out.println("You will be asked for two numbers.\nThe program will then divide the first number by the second number for you.");
        System.out.println("Please enter the first number: ");
        Scanner scan1 = new Scanner(System.in);
        
        if(!scan1.hasNext("[A-Za-z]*")) {
        
            number1 = scan1.nextFloat();
            System.out.println("Please enter the second number: ");
            Scanner scan2 = new Scanner(System.in);
            
            if(!scan2.hasNext("[A-Za-z]*")) {
                number2 = scan2.nextFloat();

                System.out.println("The two numbers you entered were " + number1 + " and " + number2);

                if (number2 == 0) {
                    System.out.println("There was a problem. You cannot divide by zero.");
                }
                else {
                    result = number1/number2;
                    System.out.println("Dividing the first number by the second number gives you: " + result);
                }
            }
            else {
            System.out.println("Sorry, you didn't enter a number.");
            }
        }
        else {
            System.out.println("Sorry, you didn't enter a number.");
        }
        
       
    }
}
