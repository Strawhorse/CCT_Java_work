
// John Bracken
// sba22328
// Sorry I didn't get to incorporate a loop that would iterate through all students in list; very busy at work. Apologies.

package johnbr.continuousassessment1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.regex.Pattern;

// class name for continuous assessment
public class ContinuousAssessment1 {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        // creating a string variable for the file path
        // change this if needed, Sam
        // program was written using Ubuntu so current file pathing is single forward slash
        String filePath = "/home/seanobr/CCT/Object oriented approach/Code/CA/student.txt";


        // create a scanner object to read in three lines from the text file and set each line as a variable
        Scanner scanFile = new Scanner(new FileReader(filePath));
                

        String fullName = scanFile.nextLine();
        int workloadNumber = Integer.parseInt(scanFile.nextLine());
        String studentNumber = scanFile.nextLine();

        // split the name into two+ names by separating the whitespace using regex and creating a String array object of the name
        // will help to deal with part (b) of the task, ensuring that second name is split from first name by a space
        // each part of the String array can now be called using [] notation
        String[] splitName = fullName.trim().split("\\s+");

        //Five methods to make the assignment work
        //1. Boolean checker for the first name to see if it is text only
        //2. Surname checker to check that the surname can be 'text and/or numbers' - already sepated using String array above
        //3. Check the workload number from the text file and return the respective result
        //4. Student number checker, reading in the string and outputting a boolean if matching pattern
        //5. Write method to write output to new file named status.txt in correct format, only if inputs from previous methods is correct
        boolean firstNameChecker = checkFirstName(splitName[0]);
        boolean surnameChecker = checkSurname(splitName[1]);
        String workloadString = checkWorkload(workloadNumber); 
        boolean studentNumberChecker = checkStudentNumber(studentNumber);
        writeStudent(studentNumber, splitName, firstNameChecker, surnameChecker, workloadString, studentNumberChecker);

    }
    
    
    // create a method to put the other methods together and output to a file (or create it if not existing)
    // decided not to use Bufferedwriter because too many transformations are needed in the data; used Printwriter instead for simplicity
    
    public static void writeStudent(String studentNumber, String[] splitName, boolean firstNameChecker, boolean surnameChecker, String workloadString, boolean studentNumberChecker) throws IOException {
        PrintWriter fileWriter = new PrintWriter("/home/seanobr/CCT/Object oriented approach/Code/CA/status.txt");
        if(firstNameChecker && surnameChecker && studentNumberChecker && (!"Workload is not an acceptable number".equals(workloadString))) {
            fileWriter.println(studentNumber + " - " + splitName[1]);
            fileWriter.println(workloadString);
            fileWriter.close();
        }
        else{
            System.out.println("There was a problem writing the data to the file. Please check the inputs again.");
        }
    }
    
    

    // method to check student number against required pattern
    // also as per extra work checking year number is at least 2020 and that the end number is not too large
    
    public static boolean checkStudentNumber(String studentNumber) {
        String[] studentNumberParts = studentNumber.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
        if ((Integer.parseInt(studentNumberParts[2])>200) || (studentNumber.length() < 6 || (Integer.parseInt(studentNumberParts[0])<20))) {
            System.out.println("Sorry, the student number is too short, the year was incorrect, or the end number is too large");
            return false;
        } else if ((studentNumberParts[0].length() == 2) && (studentNumberParts[2].length() >= 2) && ((studentNumberParts[1].length() > 1) && (studentNumberParts[1].length()<4))) {
            return true;
        }
            return false;
        }
       

    // this method is to check the workload number from the text file and return the respective result
    // takes an int parameter read in above using the scanner and outputs a String with the result
    // throws an error is the number entered is incorrect (i.e. more than 8, as per instructions)
    public static String checkWorkload(int workload) {
        if (workload == 1) {
            return "Very Light";
        }
        else if (workload == 2) {
            return "Light";
        }
        else if(workload == 3 || workload == 4 || workload == 5) {
            return "Part Time";
        }
        else if(workload >=6 && workload <9) {
            return "Full time";
        }
        else {
            return "Workload is not an acceptable number";
        }
    }
    
    
    //    method to read in the students first name and check if it is valid
    //    must be only text 
    //    After this, the first name will be unused in the output
    
    public static boolean checkFirstName(String firstName) {
        return Pattern.matches("[a-zA-Z]+", firstName);
    }
    
        
    // surname checking method which reads in a string and outputs a boolean
    // checks pattern to make sure second name can be text and/or numbers
    
    public static boolean checkSurname(String surname) {
        return Pattern.matches("^[A-Za-z/d]+", surname);
    }
}
