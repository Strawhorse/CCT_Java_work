package johnbr.bufferedreaderaddnumbers;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BufferedreaderAddNumbers {

    public static void main(String[] args) {

        int firstNumber = 0;
        int secondNumber = 0;
        
        System.out.println("Add two numbers with BufferedReader: ");
       
        
        BufferedReader reader1 = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Please enter the first number: ");

        try{
            firstNumber = Integer.parseInt(reader1.readLine());         
        }
        catch(Exception e) {
            System.out.println("There is a problem in your code.");
        }
        System.out.println("Your first number is: " + firstNumber);

        BufferedReader reader2 = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Please enter the second number: ");

        try{
            secondNumber = Integer.parseInt(reader2.readLine());
        }
        catch(Exception e) {
            System.out.println("There is a problem in your code.");
        }
        System.out.println("Your second number is: " + secondNumber);
        
        int sum = firstNumber + secondNumber;
                
        System.out.println("The total of your two numbers is: " + sum);
    }
}
