package johnbr.scanneraddnumbers;

import java.util.Scanner;

public class ScannerAddNumbers {

    public static void main(String[] args) {
        System.out.println("Add two numbers with Scanner: ");
        
        Long numberOne, numberTwo, sum;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Please enter the first number: ");
        numberOne = scan.nextLong();

        System.out.println("Please enter the second number: ");
        numberTwo = scan.nextLong();
        scan.close();
        
        sum = numberOne + numberTwo;
                
        System.out.println("The sum of " + numberOne + " and " + numberTwo + " is: " + sum);
    }
}
