package johnbr.twoquestions;

import java.util.Scanner;

public class TwoQuestions {

    public static void main(String[] args) {
        String questionOne = null;
        String questionTwo = null;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("What is your quest?");
        questionOne = scan.nextLine();

        System.out.println("What is your favourite colour?");
        questionTwo = scan.nextLine();
        scan.close();
        
        System.out.println("Ah, I see your quest is to " + questionOne + " and your favourite colour is " + questionTwo);
    }
}
