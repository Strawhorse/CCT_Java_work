package johnbr.whoareyou;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class WhoAreYou {

    public static void main(String[] args) {
        System.out.println("QUESTION 1: BufferedReader + InputStreamReader");
        BufferedReader myInput = new BufferedReader(new InputStreamReader(System.in));

        String myName1;
        try{
            System.out.println("Please enter your name below: ");
            myName1 = myInput.readLine();
        }
        catch(Exception e){
            myName1 = "Error";
        }
        System.out.println("Oh, that's a very nice name, " + myName1);
        
        
        System.out.println("QUESTION 2: Scanner");
        Scanner reader = new Scanner(System.in);
        String myName2;
        System.out.println("Please enter your name below: ");
        myName2 = reader.nextLine();
        reader.close();
        System.out.println("Oh, that's a very nice name, " + myName2);
    }
}
